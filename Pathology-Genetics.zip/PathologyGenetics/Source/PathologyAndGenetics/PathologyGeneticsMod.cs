using HarmonyLib;
using Verse;

namespace PathologyAndGenetics
{

    [StaticConstructorOnStartup]
    public static class PathologyGeneticsMod
    {
        static PathologyGeneticsMod()
        {

            var harmony = new Harmony("com.pathologyandgenetics.mod");


            harmony.PatchAll();

            Log.Message("[Pathology & Genetics] Harmony patches successfully applied!");
        }
    }
}