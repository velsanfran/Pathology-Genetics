using System.Collections.Generic;
using RimWorld;
using UnityEngine;
using Verse;

namespace PathologyAndGenetics
{
    public class HediffCompProperties_AirborneSpread : HediffCompProperties
    {
        public float radius = 4f;
        public int checkInterval = 250;
        public float baseContagionChance = 0.05f;

        public HediffCompProperties_AirborneSpread()
        {
            this.compClass = typeof(HediffComp_AirborneSpread);
        }
    }

    public class HediffComp_AirborneSpread : HediffComp
    {
        public HediffCompProperties_AirborneSpread Props => (HediffCompProperties_AirborneSpread)this.props;

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);

            Pawn pawn = this.parent.pawn;
            if (pawn == null || pawn.Dead || pawn.Map == null) return;

            if (pawn.IsHashIntervalTick(Props.checkInterval))
            {
                IntVec3 pos = pawn.Position;
                Map map = pawn.Map;

                foreach (Thing thing in GenRadial.RadialDistinctThingsAround(pos, map, Props.radius, true))
                {
                    if (thing is Pawn targetPawn && targetPawn != pawn && !targetPawn.Dead && targetPawn.RaceProps.Humanlike)
                    {
                        if (!targetPawn.health.hediffSet.HasHediff(this.parent.def))
                        {
                            float baseChance = Props.baseContagionChance * this.parent.Severity;
                            float finalChance = baseChance * PathologySettings.airborneSpreadMultiplier / PathologySettings.globalImmunityPower;

                            if (Rand.Value < finalChance)
                            {
                                Hediff newHediff = HediffMaker.MakeHediff(this.parent.def, targetPawn);
                                newHediff.Severity = 0.01f;
                                targetPawn.health.AddHediff(newHediff);

                                if (PawnUtility.ShouldSendNotificationAbout(targetPawn))
                                {
                                    Messages.Message(
                                        $"{targetPawn.LabelShort} заразился ({this.parent.def.label}) воздушно-капельным путем от {pawn.LabelShort}",
                                        targetPawn, MessageTypeDefOf.NegativeHealthEvent
                                    );
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}