using HarmonyLib;
using RimWorld;
using Verse;

namespace PathologyAndGenetics.Patches
{
    [HarmonyPatch(typeof(Pawn), nameof(Pawn.SpawnSetup))]
    public static class PrionInheritancePatch
    {
        public static void Postfix(Pawn __instance, Map map, bool respawningAfterLoad)
        {
            if (__instance == null || __instance.Dead || !__instance.RaceProps.Humanlike)
                return;


            if (__instance.DevelopmentalStage == DevelopmentalStage.Baby || __instance.DevelopmentalStage == DevelopmentalStage.Child)
            {
                HediffDef prionDef = HediffDef.Named("PG_PrionDisease");
                if (prionDef == null) return;


                if (__instance.health.hediffSet.HasHediff(prionDef))
                    return;


                Pawn mother = __instance.relations?.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, x => x.gender == Gender.Female);
                Pawn father = __instance.relations?.GetFirstDirectRelationPawn(PawnRelationDefOf.Parent, x => x.gender == Gender.Male);

                bool parentHasPrions = (mother != null && mother.health.hediffSet.HasHediff(prionDef)) ||
                                       (father != null && father.health.hediffSet.HasHediff(prionDef));


                if (parentHasPrions)
                {
                    Hediff prion = HediffMaker.MakeHediff(prionDef, __instance);
                    __instance.health.AddHediff(prion);

                    if (PawnUtility.ShouldSendNotificationAbout(__instance))
                    {
                        Messages.Message(
                            $"Из-за болезни родителей новорожденный {__instance.LabelShort} унаследовал прионную инфекцию!",
                            __instance,
                            MessageTypeDefOf.NegativeHealthEvent
                        );
                    }
                }
            }
        }
    }
}