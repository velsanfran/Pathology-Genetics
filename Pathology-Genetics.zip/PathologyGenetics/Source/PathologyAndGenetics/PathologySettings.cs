using UnityEngine;
using Verse;

namespace PathologyAndGenetics
{
    public class PathologySettings : ModSettings
    {

        public static float spontaneousPrionChance = 0.001f; 
        public static float airborneSpreadMultiplier = 1.0f;  
        public static float globalImmunityPower = 1.0f;      

        public override void ExposeData()
        {
            base.ExposeData();
            Scribe_Values.Look(ref spontaneousPrionChance, "spontaneousPrionChance", 0.001f);
            Scribe_Values.Look(ref airborneSpreadMultiplier, "airborneSpreadMultiplier", 1.0f);
            Scribe_Values.Look(ref globalImmunityPower, "globalImmunityPower", 1.0f);
        }
    }

    public class PathologyMod : Mod
    {
        public static PathologySettings settings;

        public PathologyMod(ModContentPack content) : base(content)
        {
            settings = GetSettings<PathologySettings>();
        }

        public override string SettingsCategory()
        {
            return "Pathology & Genetics";
        }

        public override void DoSettingsWindowContents(Rect inRect)
        {
            Listing_Standard listing = new Listing_Standard();
            listing.Begin(inRect);

            listing.Label($"Шанс спонтанного приона: {PathologySettings.spontaneousPrionChance:P3}");
            PathologySettings.spontaneousPrionChance = listing.Slider(PathologySettings.spontaneousPrionChance, 0.0f, 0.01f);

            listing.Gap(12f);
            listing.Label($"Множитель воздушно-капельного распространения: {PathologySettings.airborneSpreadMultiplier:F2}x");
            PathologySettings.airborneSpreadMultiplier = listing.Slider(PathologySettings.airborneSpreadMultiplier, 0.1f, 5.0f);

            listing.Gap(12f);
            listing.Label($"Эффективность иммунитета пешек: {PathologySettings.globalImmunityPower:F2}x");
            PathologySettings.globalImmunityPower = listing.Slider(PathologySettings.globalImmunityPower, 0.1f, 3.0f);

            listing.End();
            base.DoSettingsWindowContents(inRect);
        }
    }
}