using Verse;

namespace PathologyAndGenetics
{
    public class HediffCompProperties_OrganRejection : HediffCompProperties
    {
        public float severityPerDay = 0.15f;

        public HediffCompProperties_OrganRejection()
        {
            compClass = typeof(HediffComp_OrganRejection);
        }
    }

    public class HediffComp_OrganRejection : HediffComp
    {
        public HediffCompProperties_OrganRejection Props => (HediffCompProperties_OrganRejection)props;

        public override void CompPostTick(ref float severityAdjustment)
        {
            base.CompPostTick(ref severityAdjustment);
            if (Pawn.IsHashIntervalTick(2000))
            {
                parent.Severity += (Props.severityPerDay / 30f);
            }
        }
    }
}