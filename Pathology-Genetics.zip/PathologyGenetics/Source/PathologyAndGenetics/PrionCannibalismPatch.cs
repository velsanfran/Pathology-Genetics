using HarmonyLib;
using RimWorld;
using Verse;

namespace PathologyAndGenetics.Patches
{
    [HarmonyPatch(typeof(Thing), nameof(Thing.Ingested))]
    public static class PrionCannibalismPatch
    {
        public static void Postfix(Thing __instance, Pawn ingester)
        {
            if (ingester == null || ingester.Dead || !ingester.RaceProps.Humanlike)
                return;

            bool isHumanMeat = false;

            if (__instance.def == ThingDefOf.Meat_Human)
            {
                isHumanMeat = true;
            }
            else if (__instance.def.IsIngestible && __instance.def.ingestible.sourceDef != null)
            {
                if (__instance.def.ingestible.sourceDef.race != null && __instance.def.ingestible.sourceDef.race.Humanlike)
                {
                    isHumanMeat = true;
                }
            }

            if (isHumanMeat)
            {
                if (Rand.Value < 0.15f)
                {
                    HediffDef prionDef = HediffDef.Named("PG_PrionDisease");
                    if (prionDef != null && !ingester.health.hediffSet.HasHediff(prionDef))
                    {
                        Hediff prion = HediffMaker.MakeHediff(prionDef, ingester);
                        ingester.health.AddHediff(prion);

                        if (PawnUtility.ShouldSendNotificationAbout(ingester))
                        {
                            Messages.Message(
                                $"{ingester.LabelShort} подхватил(а) прионную инфекцию из-за употребления человечины!",
                                ingester,
                                MessageTypeDefOf.NegativeHealthEvent
                            );
                        }
                    }
                }
            }
        }
    }
}