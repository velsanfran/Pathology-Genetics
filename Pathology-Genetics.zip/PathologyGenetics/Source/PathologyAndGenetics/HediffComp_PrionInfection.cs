using HarmonyLib;
using RimWorld;
using Verse;

namespace PathologyAndGenetics
{
	[HarmonyPatch(typeof(Thing), nameof(Thing.Ingested))]
	public static class Patch_Thing_Ingested
	{
		public static void Postfix(Thing __instance, Pawn ingester, float __result)
		{
			if (ingester == null || ingester.Dead || !ingester.RaceProps.Humanlike)
				return;

			bool isHumanMeat = false;


            if (__instance.def == ThingDefOf.Meat_Human)
            {
				isHumanMeat = true;
			}

			else if (__instance.def.IsIngestible && __instance.def.ingestible.sourceDef != null)
			{
				if (__instance.def.ingestible.sourceDef.race != null && __instance.def.ingestible.sourceDef.race.Humanlike)
				{
					isHumanMeat = true;
				}
			}

			if (isHumanMeat)
			{

				float contagionChance = 0.15f;

				if (Rand.Value < contagionChance)
				{
					HediffDef prionDef = HediffDef.Named("PG_PrionDisease");
					if (prionDef != null && !ingester.health.hediffSet.HasHediff(prionDef))
					{
						Hediff prion = HediffMaker.MakeHediff(prionDef, ingester);
						ingester.health.AddHediff(prion);

						if (PawnUtility.ShouldSendNotificationAbout(ingester))
						{
							Messages.Message(
								$"{ingester.LabelShort} заражается прионной инфекцией из-за употребления человечины!",
								ingester,
								MessageTypeDefOf.NegativeHealthEvent
							);
						}
					}
				}
			}
		}
	}
}